import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';
import routes from './routes/routes.js';
import { AppError, errorHandler } from './utils/errorHandling.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// ES modules fix for __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/************** Middlewares ****************/
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'views')));
app.use(express.json({limit: '10kb'}));
app.use(bodyParser.urlencoded({ extended: true })); 

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    next();
});

const corsOptions = {
    origin: '*',
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

/************** Routes ****************/
app.use('/', routes);

app.use((req, res, next) => {
    const err = new AppError(`Can't find ${req.originalUrl} on this server.`, 404);
    next(err);
});

app.use(errorHandler);

/*** Listen to Port ***/
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

export default app;
