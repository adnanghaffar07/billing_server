import Onfleet from '@onfleet/node-onfleet';
import dotenv from 'dotenv';

dotenv.config();

// Initialize the Onfleet client
const onfleet = new Onfleet(process.env.ONFLEET_AUTH_TOKEN);

// Common function to get admin details
const getAdminDetails = async (adminId) => {
    try {
        const admins = await onfleet.administrators.get();
        return admins.find((admin) => admin.id === adminId);
    } catch (error) {
        console.error('Error fetching admin details:', error);
        throw error;
    }
};

export { onfleet, getAdminDetails };
