import dotenv from 'dotenv';
import { sendSlackMessage, createTaskDeletionMessage } from '../../utils/slackConfig.js';
import { getAdminDetails } from '../../utils/onfleetConfig.js';

dotenv.config();

const handleTaskDeletion = async (req, res) => {
    try {
        const payload = req.body;
        if (!payload) {
            return res.status(404).json({ message: "Invalid payload or Not Found" });
        }

        const adminId = payload.adminId;
        if (!adminId) {
            return res.status(403).json({ message: "Admin ID not Defined" });
        }

        // Fetch admin details using Onfleet SDK
        const admin = await getAdminDetails(adminId);

        // Extract details from payload for Slack message
        const taskShortId = payload.data.task.shortId;
        const adminName = admin ? admin.name : "Unknown Admin";
        const recipientName = payload.data.task.recipients[0].name;
        const recipientAddress = `${payload.data.task.destination.address.street}, ${payload.data.task.destination.address.city}, ${payload.data.task.destination.address.state} ${payload.data.task.destination.address.postalCode}, ${payload.data.task.destination.address.country}`;

        // Slack notification logic
        const messagePayload = createTaskDeletionMessage({
            taskShortId,
            adminName,
            recipientName,
            recipientAddress
        });

        await sendSlackMessage({
            text: messagePayload.text,
            blocks: messagePayload.blocks
        });

        res.status(200).json({
            message: "Task deleted notification sent successfully to Slack",
        });
    } catch (error) {
        console.error("Error handling task deletion notification:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

export { handleTaskDeletion };
