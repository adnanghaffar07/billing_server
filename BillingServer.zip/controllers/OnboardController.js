import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const showOnboardPage = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/onboard.html'));
};

export const showOnfleetOnboardPage = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/onboard-onfleet.html'));
};

export const showStitchOnboardPage = (req, res) => {
    res.sendFile(path.join(__dirname, '../views/onboard-stitch.html'));
};

const validateDriverData = (firstName, lastName, phone) => {
    const errors = [];
    
    if (!firstName || firstName.trim().length === 0) {
        errors.push('First name is required');
    }
    
    if (!lastName || lastName.trim().length === 0) {
        errors.push('Last name is required');
    }
    
    if (!phone || phone.trim().length === 0) {
        errors.push('Phone number is required');
    } else {
        // Basic phone number validation (at least 10 digits)
        const phoneRegex = /^\+?[\d\s-]{10,}$/;
        if (!phoneRegex.test(phone)) {
            errors.push('Invalid phone number format');
        }
    }
    
    return errors;
};

export const handleOnfleetOnboard = async (req, res) => {
    try {
        const { firstName, lastName, email, phone } = req.body;
        
        const validationErrors = validateDriverData(firstName, lastName, phone);
        if (validationErrors.length > 0) {
            return res.status(400).json({
                success: false,
                errors: validationErrors
            });
        }

        const fullName = `${firstName.trim()} ${lastName.trim()}`;
        // TODO: Add Onfleet driver creation logic here
        
        res.status(200).json({
            success: true,
            message: 'Driver successfully onboarded to Onfleet'
        });
    } catch (error) {
        console.error('Error onboarding driver to Onfleet:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to onboard driver to Onfleet'
        });
    }
};

export const handleStitchOnboard = async (req, res) => {
    try {
        const { firstName, lastName, email, phone } = req.body;
        
        const validationErrors = validateDriverData(firstName, lastName, phone);
        if (validationErrors.length > 0) {
            return res.status(400).json({
                success: false,
                errors: validationErrors
            });
        }

        const fullName = `${firstName.trim()} ${lastName.trim()}`;
        // TODO: Add Stitch driver creation logic here
        
        res.status(200).json({
            success: true,
            message: 'Driver successfully onboarded to Stitch'
        });
    } catch (error) {
        console.error('Error onboarding driver to Stitch:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to onboard driver to Stitch'
        });
    }
};
