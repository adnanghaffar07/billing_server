import express from 'express';
import * as OrderController from '../controllers/OrderController.js';
import * as HealthController from '../controllers/HealthController.js';
import * as OnboardController from '../controllers/OnboardController.js';
import { handleTaskDeletion } from '../controllers/OnFleet/taskDeleted.js';
import { handleTaskAssigned } from '../controllers/OnFleet/taskAssigned.js';
import { driver_assigned, driver_coordinates, driver_unassigned } from '../controllers/DriverController.js';

const router = express.Router();

//-- *********** Import Controller Functions *********** --// 

router.get("/", (req, res) => {
  res.redirect('https://trydragonfly.com')
});

/**Health Check */
router.route("/health")
  .get(HealthController.check_heatlth);

/** Onboarding Routes */
router.get('/onboard', OnboardController.showOnboardPage);
router.get('/onboard/onfleet', OnboardController.showOnfleetOnboardPage);
router.get('/onboard/stitch', OnboardController.showStitchOnboardPage);
router.post('/api/onboard/onfleet', OnboardController.handleOnfleetOnboard);
router.post('/api/onboard/stitch', OnboardController.handleStitchOnboard);

/** Order Routes Below */
router.route("/order/:id/status")
  .get(OrderController.get_order_status)
  .post(OrderController.get_order_status);

router.route("/order/:id/details")
  .post(OrderController.order_details_change);

router.route("/order")
  .post(OrderController.order_details);

router.route("/order/:id/dsp_declined")
  .get(OrderController.order_dsp_declined)
  .post(OrderController.order_dsp_declined);

/** Driver Routes Below */
router.route("/driver/:id/assigned")
  .get(driver_assigned)
  .post(driver_assigned);

router.route("/driver/:id/unassigned")
  .get(driver_unassigned)
  .post(driver_unassigned);

router.route("/driver/:id/coordinates")
  .get(driver_coordinates)
  .post(driver_coordinates);

/** OnFleet Task Deletion Route */
router.route("/onfleet/deleteTask")
  .post(handleTaskDeletion);

/** OnFleet Task Assigned Route */
router.route("/onfleet/assignTask")
  .post(handleTaskAssigned);

export default router;
